#!/bin/bash

source /etc/profile
ln -s /usr/local/luajit/lib/libluajit-5.1.so.2 /lib64/libluajit-5.1.so.2
cd /usr/local/src/;tar zxpf nginx-1.14.2.tar.gz

if [ `grep /usr/local/luajit/lib /etc/profile|wc -l` -gt 0 ];then
	echo "lua is install ....."
else
	mkdir /usr/local/nginx/
	echo "/usr/local/luajit/lib/" >>/etc/ld.so.conf
	echo "export LUAJIT_LIB=/usr/local/luajit/lib" >>/etc/profile
	echo "export LUAJIT_INC=/usr/local/luajit/include/luajit-2.0"  >>/etc/profile
	cd /usr/local/src/;tar zxpf LuaJIT-2.0.4.tar.gz;
	ln -s /usr/local/nginx /nginx
	mkdir /usr/local/luajit/;cd /usr/local/src/LuaJIT-2.0.4;
	make install PREFIX=/usr/local/luajit/
	ldconfig	
fi
if [ -d "/usr/local/openssl" ];then
        echo "openssl is install ....."
else

        cd /usr/local/src/openssl-1.0.2q;./config --prefix=/usr/local/openssl 
        make&&make install

fi
source /etc/profile
cd /usr/local/src/nginx-1.14.2
./configure --prefix=/usr/local/nginx \
--with-ipv6 \
--with-http_realip_module \
--with-http_ssl_module \
--with-http_stub_status_module \
--with-zlib=/usr/local/src/zlib-1.2.11 \
--with-pcre=/usr/local/src/pcre-8.41 \
--with-openssl=/usr/local/src/openssl-1.0.2q \
--add-module=/usr/local/src/ngx_devel_kit-0.3.1rc1 \
--add-module=/usr/local/src/lua-nginx-module-0.10.12rc2 \
--add-module=/usr/local/src/ngx_cache_purge-2.3
make -j2 && make install
